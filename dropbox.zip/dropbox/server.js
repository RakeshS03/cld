const express = require('express');
const multer = require('multer');
const Dropbox = require('dropbox').Dropbox;
const fetch = require('isomorphic-fetch');
const path = require('path');

const app = express();
const port = 3000;

// Dropbox access token
//const DROPBOX_ACCESS_TOfafKEN = '';

// Set up multer for file uploads (in-memory storage for simplicity)
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// In-memory array to store patient data
let patients = [];

// Endpoint: Add new patient (including file upload to Dropbox)
app.post('/api/patients', upload.single('image'), async (req, res) => {
    const { id, name, doctor, medicine } = req.body;

    // Check if patient ID already exists
    if (patients.some((patient) => patient.id === id)) {
        return res.status(400).json({ message: 'Patient with this ID already exists' });
    }

    const newPatient = { id, name, doctor, medicine };

    // Upload image to Dropbox if provided
    if (req.file) {
        try {
            const dbx = new Dropbox({ accessToken: DROPBOX_ACCESS_TOKEN, fetch });
            const dropboxPath = `/PatientImages/${req.file.originalname}`;
            await dbx.filesUpload({ path: dropboxPath, contents: req.file.buffer });
            newPatient.imageUrl = dropboxPath; // Save Dropbox path to patient data
        } catch (error) {
            console.error('Error uploading to Dropbox:', error);
            return res.status(500).json({ message: 'Failed to upload image to Dropbox' });
        }
    }

    patients.push(newPatient); // Add new patient to the array
    res.status(201).json(newPatient); // Return the newly added patient
});

// Endpoint: Upload a file to Dropbox
app.post('/api/uploadFile', upload.single('file'), async (req, res) => {
    const { originalname } = req.file;
    try {
        const dbx = new Dropbox({ accessToken: DROPBOX_ACCESS_TOKEN, fetch });
        const dropboxPath = `/UploadedFiles/${originalname}`;
        
        // Upload file to Dropbox
        await dbx.filesUpload({ path: dropboxPath, contents: req.file.buffer });
        
        res.status(200).json({ message: 'File uploaded successfully', filePath: dropboxPath });
    } catch (error) {
        console.error('Error uploading file to Dropbox:', error);
        res.status(500).json({ message: 'Failed to upload file to Dropbox' });
    }
});

// Endpoint: Get all images from Dropbox
app.get('/api/images', async (req, res) => {
    try {
        const dbx = new Dropbox({ accessToken: DROPBOX_ACCESS_TOKEN, fetch });

        // Fetch files from Dropbox folder
        const response = await dbx.filesListFolder({ path: '/PatientImages' });

        // Check if entries exist
        if (!response.result.entries || response.result.entries.length === 0) {
            return res.json([]); // No images found
        }

        const imageLinks = [];
        for (let i = 0; i < response.result.entries.length; i++) {
            const entry = response.result.entries[i];
            const linkResponse = await dbx.filesGetTemporaryLink({ path: entry.path_lower });
            imageLinks.push({ name: entry.name, url: linkResponse.result.link });
        }

        res.json(imageLinks);
    } catch (error) {
        console.error('Error retrieving images from Dropbox:', error);
        res.status(500).json({ message: 'Failed to retrieve images from Dropbox', error: error.message });
    }
});

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
